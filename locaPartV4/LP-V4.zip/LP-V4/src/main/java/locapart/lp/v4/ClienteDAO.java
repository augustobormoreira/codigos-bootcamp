/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;

import java.util.Date;

/**
 *
 * Classe DAO responsável por fazer o intermédio entre as operações de acesso a dados ou cadastro que no caso é responsabilidade
 * da controladora.
 */
public class ClienteDAO {
    Sis_LocaPart controladora;
    
    public ClienteDAO(){
        controladora = new Sis_LocaPart();
    }
    
    public void realizaCadastro(PessoaCliente pc){
        controladora.cadastraCliente(pc);
    }
    
    public PessoaCliente buscaCliente(String cpf){
        return controladora.buscaCliente(cpf);
    }
    
    public Date verificaData(String date){
        return controladora.dataStringificar(date);
    }
}
