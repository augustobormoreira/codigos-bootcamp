/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;

import java.util.Date;

/**
 *
 * Classe DAO responsável por fazer o intermédio entre as operações de acesso a dados ou cadastro que no caso é responsabilidade
 * da controladora.
 */
public class ApartamentoDAO {
    Sis_LocaPart controladora;
    
    public ApartamentoDAO(){
        controladora = new Sis_LocaPart();
    }
    
    public void realizaCadastro(Apartamento ap){
        controladora.cadastraApartamento(ap);
    }
    
    public Apartamento buscaApartamento(int idAp){
        return controladora.buscaApartamento(idAp);
    }
    
    public Date verificaData(String date){
        return controladora.dataStringificar(date);
    }
    
}
