/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;
import java.text.SimpleDateFormat;
import javax.persistence.*;
import java.util.*;

/**
 *
 * Classe controladora, essa classe é responsável pelo funcionamento do sistema. Possui dois atributos do Hibernate
 * a EntityManagerFactory e a EntityManager
 */
public class Sis_LocaPart {
    EntityManagerFactory entityManagerFactory;
    EntityManager entityManager;
    
    /* Construtor da controladora inicia a entityManagerFactory, a entityManagere já inicia uma transação, que será
    necessária para fazer as persistências ao banco de dados*/
    public Sis_LocaPart(){
        entityManagerFactory = Persistence.createEntityManagerFactory("pt1");
        entityManager = entityManagerFactory.createEntityManager();
        entityManager.getTransaction().begin();
    }
    
    
    /* Método realizar locação implementado conforme as documentações */
    public void realizarLocacao(String cpf_CLI, String cpf_FUNC, int idAp, Date dataInicio, Date dataFinal, Double valorAcordado){
        PessoaCliente pc = entityManager.find(PessoaCliente.class, cpf_CLI);
        PessoaFuncionario pf = entityManager.find(PessoaFuncionario.class, cpf_FUNC);
        Apartamento ap = entityManager.find(Apartamento.class, idAp);
        
        Locacao loc = new Locacao(pc, pf, ap, dataInicio, dataFinal, valorAcordado);
        ap.setLoc(loc);
        loc.setApts(ap);
        
        entityManager.persist(loc);
        
        entityManager.getTransaction().commit();
        
    }
    /* Método responsável por registrar a visita no banco de dados conforme a documentação */
    public void agendarVisita(Date dataVisita, String clicpf, String funcpf, int idAp){
        PessoaCliente pc = this.buscaCliente(clicpf);
        PessoaFuncionario pf = this.buscaFuncionario(funcpf);
        Apartamento apt = this.buscaApartamento(idAp);
        Visita visita = new Visita(dataVisita, pc, pf, apt);
        
        entityManager.persist(visita);
        entityManager.getTransaction().commit();
    }
    
    /* Método responsável por efetuar o login do usuario, recebe o user e a password como parâmetro, 
    utiliza a string sql em formato jql para procurar um funcionario no banco de dados, se o funcionario
    existir ele preenche o objeto pf, caso contrario pf recebe null*/
    public PessoaFuncionario efetuarLogin(String user, String password){
        String sql = "select a from PessoaFuncionario a where a.usuario = :user AND a.senha = :password";
        PessoaFuncionario pf = entityManager.
                createQuery(sql, PessoaFuncionario.class)
                .setParameter("user", user)
                .setParameter("password", password)
                .getSingleResult();
        
        
        return pf;
    }
    
    /* Método responsável por buscar um cliente, recebe como parâmetro o cpf do cliente desejado e utiliza de uma string
    em formato jpql para procurar o cliente no banco de dados. Se achar o cpf preenche o objeto pc, caso contrario
    retorna null*/
    public PessoaCliente buscaCliente(String clicpf) {
        String sql = "select a from PessoaCliente a where a.cpf = :cpfuser";
        PessoaCliente pc = entityManager.
                createQuery(sql, PessoaCliente.class)
                .setParameter("cpfuser", clicpf)
                .getSingleResult();
        
        return pc;
    }
    
    public Apartamento buscaApartamento(int idAp){
        String sql = "select a from Apartamento a where a.idAp = :idapartamento";
        Apartamento ap = entityManager.
                createQuery(sql, Apartamento.class)
                .setParameter("idapartamento", idAp)
                .getSingleResult();
        
        return ap;
    }
    
    /* Método responsável por buscar um funcionario, recebe como parâmetro o cpf do funcionario desejado e utiliza de uma string
    em formato jpql para procurar o funcionario no banco de dados. Se achar o cpf preenche o objeto pf, caso contrario
    retorna null*/
    public PessoaFuncionario buscaFuncionario(String funcpf) {
        String sql = "select a from PessoaFuncionario a where a.cpf = :cpfuser";
        PessoaFuncionario pf = entityManager.
                createQuery(sql, PessoaFuncionario.class)
                .setParameter("cpfuser", funcpf)
                .getSingleResult();
        
        return pf;
    }
    
    /* Método responsável por preencher a tabela de disponibilidade de apartamentos, utiliza de uma string em formato jpql
    procurando pelo atributo disponivel da tabela de apartamentos*/
    public List<Apartamento> preencheTabela() {
         String sql = "select a from Apartamento a where a.disponivel = :disponibilidade";
         List<Apartamento> apartamentos = entityManager.
                 createQuery(sql, Apartamento.class)
                 .setParameter("disponibilidade", true).
                 getResultList();
        
         return apartamentos;
        
    }

    /* Método responsável por fazer o parse de uma string recebida para o formato Date */
    public Date dataStringificar(String dateIn) {
       try{
           SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd");
           return sf.parse(dateIn);
       }catch(Exception e){
           e.printStackTrace();
       }
       
       return null;
    }

    /* Método responsável por cadastrar um funcionário. Recebe um funcionario como parâmetro e chama o entityManager
    cuja transação já foi iniciada, utiliza o persist para salvar e o commit para subir para o banco de dados*/
    public void cadastraFuncionario(PessoaFuncionario pf) {
       entityManager.persist(pf);
       
       entityManager.getTransaction().commit();
    }
    
     /* Método responsável por cadastrar um cliente. Recebe um cliente como parâmetro e chama o entityManager
    cuja transação já foi iniciada, utiliza o persist para salvar e o commit para subir para o banco de dados*/
    public void cadastraCliente(PessoaCliente pc) {
       entityManager.persist(pc);
       
       entityManager.getTransaction().commit();
    }
    
     /* Método responsável por cadastrar um apartamento. Recebe um apartamento como parâmetro e chama o entityManager
    cuja transação já foi iniciada, utiliza o persist para salvar e o commit para subir para o banco de dados*/
    public void cadastraApartamento(Apartamento ap) {
        entityManager.persist(ap);
        entityManager.getTransaction().commit();                                                    
    }
    
}
