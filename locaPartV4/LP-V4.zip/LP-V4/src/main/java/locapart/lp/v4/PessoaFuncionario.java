/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;
import javax.persistence.*;
import java.util.*;

/**
 *
 * Classe responsável por representar um Funcionario. Utiliza da JPA para representar a entidade do banco de dados
 */
@Entity
public class PessoaFuncionario extends Pessoa {
    @Column
    private Double salario;
    
    @Column
    private Double jornada;
    
    @Column
    private String cargo;
    
    @Column
    private String usuario;
    
    @Column
    private String senha;
    
     @OneToMany(
        mappedBy = "func",
        cascade = CascadeType.ALL,
        orphanRemoval = true
    )
     private List<Locacao> locacoesResponsavel = new ArrayList<>();

    public PessoaFuncionario(){
        
    }
     
    public PessoaFuncionario(Double salario, Double jornada, String cargo, String usuario, String senha, String cpf, String nome, String endereco, String rg, String estadocivil, Date dataNascimento) {
        super(cpf, nome, endereco, rg, estadocivil, dataNascimento);
        this.salario = salario;
        this.jornada = jornada;
        this.cargo = cargo;
        this.usuario = usuario;
        this.senha = senha;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }

    public Double getJornada() {
        return jornada;
    }

    public void setJornada(Double jornada) {
        this.jornada = jornada;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    
    
}
