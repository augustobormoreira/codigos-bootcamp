/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;

import java.util.Date;

/**
 *
 * Classe DAO responsável por fazer o intermédio entre as operações de acesso a dados ou cadastro que no caso é responsabilidade
 * da controladora.
 */
public class FuncDAO {
    
    Sis_LocaPart controladora;
    
    public FuncDAO(){
        controladora = new Sis_LocaPart();
    }
    
    public void realizaCadastro(PessoaFuncionario pf){
        controladora.cadastraFuncionario(pf);
    }
    
    public PessoaFuncionario buscaFuncionario(String cpf){
        return controladora.buscaFuncionario(cpf);
    }
    
    public Date verificaData(String date){
        return controladora.dataStringificar(date);
    }
    
}
