package locapart.lp.v4;
import javax.persistence.*;
import java.util.*;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * Classe responsável por representar um Cliente. Utiliza da JPA para representar a entidade do banco de dados
 */
@Entity
public class PessoaCliente extends Pessoa {
    
    @OneToMany(
        mappedBy = "cli",
        cascade = CascadeType.ALL,
        orphanRemoval = true
    )
    private List<Locacao> locacoes = new ArrayList<>();
    
    @Column
    private double cliente_renda;
    
    public PessoaCliente(){
        
    }

    public PessoaCliente(double cliente_renda, String cpf, String nome, String endereco, String rg, String estadocivil, Date dataNascimento) {
        super(cpf, nome, endereco, rg, estadocivil, dataNascimento);
        this.cliente_renda = cliente_renda;
    }
    
    public double getCliente_renda() {
        return cliente_renda;
    }

    public void setCliente_renda(double cliente_renda) {
        this.cliente_renda = cliente_renda;
    }    
}
