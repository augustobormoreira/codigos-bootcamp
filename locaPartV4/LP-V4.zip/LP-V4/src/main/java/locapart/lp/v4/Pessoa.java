/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;
import java.util.Date;
import javax.persistence.*;

/**
 *
 * Classe responsável por representar uma Pessoa. Utiliza da JPA para representar a entidade do banco de dados
 */
@Entity
@Inheritance(strategy = InheritanceType.JOINED)
public class Pessoa {    
    @Id
    private String cpf;
    
    @Column
    private String nome;
    
    @Column
    private String endereco;
    
    @Column
    private String rg;
    
    @Column
    private String estadocivil;
    
    @Column
    private Date dataNascimento;
    
       
    public Pessoa(){
        
    }
    
    public Pessoa ( String cpf, String nome, String endereco, String rg, String estadocivil, Date dataNascimento){
        this.cpf = cpf;
        this.nome = nome;
        this.endereco = endereco;
        this.rg = rg;
        this.estadocivil = estadocivil;
        this.dataNascimento = dataNascimento;
    }
    
    public String stringificar(){
        return "CPF: " + cpf + " Nome: " + nome + " RG: " + rg; 
    }
    
    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void setEstadocivil(String estadocivil) {
        this.estadocivil = estadocivil;
    }

    public void setDataNascimento(Date dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public String getCpf() {
        return cpf;
    }

    public String getNome() {
        return nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public String getRg() {
        return rg;
    }

    public String getEstadocivil() {
        return estadocivil;
    }

    public Date getDataNascimento() {
        return dataNascimento;
    }
    
    
    
    
}

