/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;
import javax.persistence.*;
/**
 *
 * Classe responsável por representar um Apartamento. Utiliza da JPA para representar a entidade do banco de dados
 */
@Entity
public class Apartamento {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idAp;
    
    @Column
    private int numApto;
    
    @Column
    private int numBanheiros;
    
    @Column
    private int numQuartos;
    
    @Column
    private int vagaGaragem;
    
    @Column
    private int andar;
    
    @Column
    private double valorCondo;
    
    @Column
    private double valorAluguel;
    
    @Column
    private String endereco;
    
    @Column
    private boolean disponivel;
    
    @ManyToOne(fetch = FetchType.EAGER)
    private Locacao loc;

    public Apartamento(){
        
    }

    public Locacao getLoc() {
        return loc;
    }

    public void setLoc(Locacao loc) {
        this.loc = loc;
        this.disponivel = false;
    }
    
    public Apartamento(int numApto, int numBanheiros, int numQuartos, int vagaGaragem, int andar, double valorCondo, double valorAluguel, String endereco, boolean disponivel) {
        this.idAp = idAp;
        this.numApto = numApto;
        this.numBanheiros = numBanheiros;
        this.numQuartos = numQuartos;
        this.vagaGaragem = vagaGaragem;
        this.andar = andar;
        this.valorCondo = valorCondo;
        this.valorAluguel = valorAluguel;
        this.endereco = endereco;
        this.disponivel = disponivel;
    }

    public int getIdAp() {
        return idAp;
    }

    public int getNumApto() {
        return numApto;
    }

    public void setNumApto(int numApto) {
        this.numApto = numApto;
    }

    public int getNumBanheiros() {
        return numBanheiros;
    }

    public void setNumBanheiros(int numBanheiros) {
        this.numBanheiros = numBanheiros;
    }

    public int getNumQuartos() {
        return numQuartos;
    }

    public void setNumQuartos(int numQuartos) {
        this.numQuartos = numQuartos;
    }

    public int getVagaGaragem() {
        return vagaGaragem;
    }

    public void setVagaGaragem(int vagaGaragem) {
        this.vagaGaragem = vagaGaragem;
    }

    public int getAndar() {
        return andar;
    }

    public void setAndar(int andar) {
        this.andar = andar;
    }

    public double getValorCondo() {
        return valorCondo;
    }

    public void setValorCondo(double valorCondo) {
        this.valorCondo = valorCondo;
    }

    public double getValorAluguel() {
        return valorAluguel;
    }

    public void setValorAluguel(double valorAluguel) {
        this.valorAluguel = valorAluguel;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public boolean isDisponivel() {
        return disponivel;
    }

    public void setDisponivel(boolean disponivel) {
        this.disponivel = disponivel;
    }
    
    
    
    
}
