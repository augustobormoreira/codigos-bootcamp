/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.Locacao to edit this template
 */
package locapart.lp.v4;
import javax.persistence.*;
import java.util.*;

/**
 *
 * Classe responsável por representar uma Locacao. Utiliza da JPA para representar a entidade do banco de dados
 */
@Entity
public class Locacao {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idLocacao;
    
    @ManyToOne(fetch = FetchType.EAGER)
    private PessoaCliente cli;
    
    
    @ManyToOne(fetch = FetchType.EAGER)
    private PessoaFuncionario func;
    
    @OneToMany(
        mappedBy = "loc",
        cascade = CascadeType.ALL,
        orphanRemoval = true
    )
    private List<Apartamento> apts = new ArrayList<>();
    
    @Column
    private Date dataInicio;
    
    @Column
    private Date dataFim;
    
    @Column
    private double valorAcordado;

    public PessoaCliente getCli() {
        return cli;
    }

    public List<Apartamento> getApts() {
        return apts;
    }

    public void setApts(List<Apartamento> apts) {
        this.apts = apts;
    }
    
    public void setApts(Apartamento apt){
        this.apts.add(apt);
    }

    public void setCli(PessoaCliente cli) {
        this.cli = cli;
    }

    public PessoaFuncionario getFunc() {
        return func;
    }

    public void setFunc(PessoaFuncionario func) {
        this.func = func;
    }

    public Date getDataInicio() {
        return dataInicio;
    }

    public void setDataInicio(Date dataInicio) {
        this.dataInicio = dataInicio;
    }

    public Date getDataFim() {
        return dataFim;
    }

    public void setDataFim(Date dataFim) {
        this.dataFim = dataFim;
    }

    public double getValorAcordado() {
        return valorAcordado;
    }

    public void setValorAcordado(double valorAcordado) {
        this.valorAcordado = valorAcordado;
    }

    public Locacao(PessoaCliente cli, PessoaFuncionario func, Apartamento apt, Date dataInicio, Date dataFim, double valorAcordado) {
        this.cli = cli;
        this.func = func;
        this.dataInicio = dataInicio;
        this.dataFim = dataFim;
        this.valorAcordado = valorAcordado;
    }
    
    public Locacao(){
        
    }
    
    
    
}
