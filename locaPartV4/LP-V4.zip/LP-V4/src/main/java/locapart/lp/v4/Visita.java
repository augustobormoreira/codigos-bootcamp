/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package locapart.lp.v4;
import javax.persistence.*;
import java.util.*;

/**
 *
 * Classe Visita criada implementando JPA representando uma entidade do banco de dados.
 */
@Entity
public class Visita {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int idVisita;
    
    @Column
    private Date dataVisita;
    
    @OneToOne
    private PessoaCliente cli;
    
    @OneToOne
    private PessoaFuncionario func;
    
    @OneToOne
    private Apartamento apt;

    public Visita(Date dataVisita, PessoaCliente cli, PessoaFuncionario func, Apartamento apt) {
        this.dataVisita = dataVisita;
        this.cli = cli;
        this.func = func;
        this.apt = apt;
    }

    public Date getDataVisita() {
        return dataVisita;
    }

    public void setDataVisita(Date dataVisita) {
        this.dataVisita = dataVisita;
    }

    public PessoaCliente getCli() {
        return cli;
    }

    public void setCli(PessoaCliente cli) {
        this.cli = cli;
    }

    public PessoaFuncionario getFunc() {
        return func;
    }

    public void setFunc(PessoaFuncionario func) {
        this.func = func;
    }

    public Apartamento getApt() {
        return apt;
    }

    public void setApt(Apartamento apt) {
        this.apt = apt;
    }
    
    
    
}
